using System;
using DeckOfCards.Game.Classes;
using DeckOfCards.Game.Interfaces;

namespace DeckOfCards
{
    class CardGame
    {
        /// <summary>
        /// Program for Card Game
        /// </summary>
        static void Main(string[] args)
        {
            IDeckOfCardFlow _deckOfCardFlow = new DeckOfCardFlow();

            Console.WriteLine("Welcome to the Card Game!\n");

            _deckOfCardFlow.StartGame();

            Console.ReadKey();
        }
    }
}
