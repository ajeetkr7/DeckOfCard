﻿using System.Collections.Generic;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Interfaces
{
    public interface IInitializeDeck
    {
        Stack<Card> Initialize();
    }
}
