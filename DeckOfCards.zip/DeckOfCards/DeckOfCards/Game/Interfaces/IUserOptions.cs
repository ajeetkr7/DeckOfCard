﻿namespace DeckOfCards.Game.Interfaces
{
    public interface IUserOptions
    {
        int GetUserOption();
    }
}
