﻿namespace DeckOfCards.Game.Interfaces
{
    public interface IDeckOfCardFlow
    {
        void StartGame();
    }
}
