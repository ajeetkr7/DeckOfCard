﻿using System.Collections.Generic;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Interfaces
{
    public interface IShuffleDeck
    {
        Stack<Card> Shuffle(Stack<Card> cards);
    }
}
