﻿using System.Collections.Generic;
using DeckOfCards.Game.Interfaces;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Classes
{
    class InitializeDeck : IInitializeDeck
    {
        /// <summary>
        /// This MEthod Responsible for Initializing the Deck Of Card
        /// </summary>
        /// <returns> Stack of Cards </returns>
        public Stack<Card> Initialize()
        {
            Stack<Card> cards = new Stack<Card>();
            List<string> suits = new List<string>() { "Clubs", "Hearts", "Spades", "Diamond" };
            List<string> cardValue = new List<string>() { "A", "1", "2", "3", "4", "5", "6", "7", "8", "9", "J", "Q", "K" };
            foreach (string suite in suits)
            {
                foreach (string value in cardValue)
                {
                    cards.Push(new Card() { Suite = suite, CardValue = value });
                }
            }

            return cards;
        }
    }
}
