﻿using System;
using DeckOfCards.Game.Interfaces;

namespace DeckOfCards.Game.Classes
{
    class UserOptions : IUserOptions
    {
        /// <summary>
        /// To get Option from the user
        /// </summary>
        /// <returns> Option provided by the user</returns>
        public int GetUserOption()
        {
            Console.WriteLine("Please Enter Your Option:- :-\n\n 1. Play a card \n 2.Shuffle the deck \n 3.Restart the game \n 4.Exit The Game\n");

            int userInput;
            try
            {
                userInput = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(String.Format("Exception occurred during Getting user input :- {0}\n", ex.GetBaseException().Message));
                userInput = 0;
            }

            return userInput;
        }
    }
}
