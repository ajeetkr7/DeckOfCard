﻿using System;
using System.Collections.Generic;
using DeckOfCards.Game.Interfaces;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Classes
{
    /// <summary>
    /// Flow Object
    /// </summary>
    class DeckOfCardFlow : IDeckOfCardFlow
    {
        IInitializeDeck _initializeDeck = new InitializeDeck();
        IShuffleDeck _shuffleDeck = new ShuffleDeck();
        IUserOptions _userOptions = new UserOptions();
        IPlayACard _playACard = new PlayACard();

        public void StartGame()
        {
            int userInput = 0;
            Stack<Card> cards = _initializeDeck.Initialize();

            while (userInput != 4)
            {
                userInput = _userOptions.GetUserOption();

                switch (userInput)
                {
                    case 1:
                        cards = _playACard.Play(cards);
                        break;
                    case 2:
                        cards = _shuffleDeck.Shuffle(cards);
                        break;
                    case 3:
                        Console.WriteLine("Restaring the game\n");
                        cards = _initializeDeck.Initialize();
                        break;
                    case 4:
                        Console.WriteLine("Exiting the Game..\n Press any Key to exit............");
                        break;
                    default:
                        Console.WriteLine("Please Try again \n");
                        break;
                }
            }

        }
    }
}
