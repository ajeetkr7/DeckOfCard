﻿using System;
using System.Collections.Generic;
using DeckOfCards.Game.Interfaces;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Classes
{
    class PlayACard : IPlayACard
    {
        /// <summary>
        /// Will show the card on the top 
        /// And remove from the stack of card
        /// </summary>
        /// <param name="cards"></param>
        /// <returns> Remaining stack of cards after removing shown card</returns>
        public Stack<Card> Play(Stack<Card> cards)
        {
            string playingCard = "";
            if (cards.Count != 0)
            {
                Card card = cards.Pop();
                playingCard = card.Suite + " " + card.CardValue;
            }
            else
            {
                playingCard = "Deck is empty. Please Restart The Game.\n";
            }

            Console.WriteLine("\nYou Got the Card - {0} \n", playingCard);

            return cards;
        }
    }
}
