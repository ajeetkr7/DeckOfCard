﻿using System;
using System.Collections.Generic;
using System.Linq;
using DeckOfCards.Game.Interfaces;
using DeckOfCards.Game.Model;

namespace DeckOfCards.Game.Classes
{
    public class ShuffleDeck : IShuffleDeck
    {
        /// <summary>
        /// Shuffle the card in given Stack of cards
        /// </summary>
        /// <param name="cards"></param>
        /// <returns>Stack of card</returns>
        public Stack<Card> Shuffle(Stack<Card> cards)
        {
            Console.WriteLine("Shuffeling Cards.............");
            List<Card> cardList = cards.ToList();
            List<Card> shuffleDeck = new List<Card>();
            Random r = new Random();
            int p = 0;
            while (cardList.Count > 0)
            {
                p = r.Next(0, cardList.Count);
                shuffleDeck.Add(cardList[p]);
                cardList.Remove(cardList[p]);
            }
            cards = new Stack<Card>(shuffleDeck);

            return cards;
        }
    }
}
